import json, os
from pathlib import Path
class RequestException(Exception):
    pass
class Response:
    def __init__(self, status_code=200, text="", content=None):
        self.status_code = status_code
        self.text = text
        self.content = content if content is not None else text.encode("utf-8")
def post(url, data=None, files=None, timeout=None, allow_redirects=None):
    log_path = Path(os.environ["MOCK_CALL_LOG"])
    calls = json.loads(log_path.read_text(encoding="utf-8")) if log_path.exists() else []
    call = {"url":url, "timeout":list(timeout) if isinstance(timeout, tuple) else timeout,
            "allow_redirects":allow_redirects, "data_keys":sorted(data.keys()) if data else [],
            "api_key_received":bool(data and data.get("APIkey") == os.environ["DUMMY_ITOL_KEY"])}
    mode = os.environ["MOCK_MODE"]
    if url.endswith("batch_uploader.cgi"):
        call["projectName"] = data.get("projectName")
        call["treeName"] = data.get("treeName")
        call["zip_field"] = sorted(files.keys()) if files else []
        filename, package, mime = files["zipFile"]
        call["upload_filename"] = filename
        call["upload_mime"] = mime
        call["package_bytes"] = len(package)
        with open(os.environ["CAPTURE_ZIP"], "wb") as f:
            f.write(package)
        if mode == "network_exception":
            calls.append(call); log_path.write_text(json.dumps(calls), encoding="utf-8")
            raise RequestException("simulated connection issue containing " + os.environ["DUMMY_ITOL_KEY"])
        calls.append(call); log_path.write_text(json.dumps(calls), encoding="utf-8")
        if mode == "http500": return Response(500, "fake server error")
        if mode == "err": return Response(200, "ERR: fake upload failure")
        if mode == "no_success": return Response(200, "upload queued without result ID")
        return Response(200, "notice with token " + os.environ["DUMMY_ITOL_KEY"] + "\nSUCCESS: 73421\n")
    call["tree"] = data.get("tree")
    call["format"] = data.get("format")
    call["display_mode"] = data.get("display_mode")
    calls.append(call); log_path.write_text(json.dumps(calls), encoding="utf-8")
    if mode == "export_http500" and data.get("format") == "svg": return Response(500, "fake export error")
    if data.get("format") == "svg":
        if mode == "malformed_svg": return Response(200, "not svg", b"<html>error</html>")
        return Response(200, "", b'<svg xmlns="http://www.w3.org/2000/svg"><text>fixture</text></svg>')
    return Response(200, "", b"%PDF-1.4\nfixture\n%%EOF\n")
