import builtins, io, os
_real_open = builtins.open
def _fake_key_open(file, *args, **kwargs):
    try:
        path = os.fspath(file)
    except TypeError:
        path = None
    if path == "/mnt/c/itol.api-key.txt":
        marker = os.environ.get("KEY_READ_MARKER")
        if marker:
            with _real_open(marker, "w", encoding="utf-8") as f:
                f.write("intercepted exact key path; dummy only")
        return io.StringIO(os.environ["DUMMY_ITOL_KEY"])
    return _real_open(file, *args, **kwargs)
builtins.open = _fake_key_open
