#!/bin/sh
# synthetic test fixture only
